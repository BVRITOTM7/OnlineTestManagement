import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
export class Test{

  constructor( public testId:number, public testTitle:String, public testDuration:String, public testQuestion1:String, public testQuestion2:String,
    public testQuestion3:string,public testTotalMarks:number,public testMarksScored:number ,
    public startTime:String,public endTime:String  ) { }
}


@Injectable({
  providedIn: 'root'
}) 
export class TestService {
  tests: Test[]
  constructor(private httpService: HttpClient) { }
 
  addTest(tests):Observable<Test>{
    console.log(tests);
     return this.httpService.post<Test>("http://localhost:8090/test/create",tests);
  }
  public  deleteTest(tests){
    return this.httpService.delete<Test>("http://localhost:8090/test/removeById/"+ tests.testId);
  }
  getAllTests(){
    return this.httpService.get<Test[]>("http://localhost:8090/test/findall")
  }
}
