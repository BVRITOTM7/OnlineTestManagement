import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddtestComponent } from './addtest/addtest.component';
import { DeletetestComponent } from './deletetest/deletetest.component';
import { ListtestComponent } from './listtest/listtest.component';

const routes: Routes = [
  
  {path:'addtest',component: AddtestComponent},
  {path:'deletetest',component:DeletetestComponent},
  {path:'listtest',component:ListtestComponent},
  ];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
