import { Component, OnInit } from '@angular/core';
import { Test,TestService } from '../test.service';
import{Router}from '@angular/router';

@Component({
  selector: 'app-deletetest',
  templateUrl: './deletetest.component.html',
  styleUrls: ['./deletetest.component.css']
})
export class DeletetestComponent implements OnInit {
  tests: Test[];
  constructor(private testservice:TestService,private router:Router){}

  ngOnInit() {
    this.testservice.getAllTests().subscribe(
      response =>this.handleSuccessfulResponse(response),
      );
  }
  handleSuccessfulResponse(response){
    this.tests=response;
  }
  deleteTest(test: Test): void { if (confirm("sure to delete?")) 
    this.testservice.deleteTest(test)
      .subscribe( data => {
        this.tests= this.tests.filter(u => u !== test);
      })
  };

  }


