import { Component, OnInit } from '@angular/core';
import { Test,TestService } from '../test.service';
import{Router}from '@angular/router';

@Component({
  selector: 'app-listtest',
  templateUrl: './listtest.component.html',
  styleUrls: ['./listtest.component.css']
})
export class ListtestComponent implements OnInit {
  tests: Test[];
  constructor(private testservice:TestService,private router:Router){}

  ngOnInit(): void {
    this.testservice.getAllTests().subscribe(
      response =>(this.handleSuccessfulResponse(response)),
      );
    }
     
  handleSuccessfulResponse(response){
        
    this.tests= response;
  }

  
  deleteTest(test: Test): void {
    this.testservice.deleteTest(test)
      .subscribe( data => {
        this.tests= this.tests.filter(u => u !== test);});
  }

  

   }
