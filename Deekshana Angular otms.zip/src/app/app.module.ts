import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddtestComponent } from './addtest/addtest.component';
import { DeletetestComponent } from './deletetest/deletetest.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TestService } from './test.service';
import {FormsModule} from '@angular/forms';
import { ListtestComponent } from './listtest/listtest.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';


@NgModule({
  declarations: [
    AppComponent,
    AddtestComponent,
    DeletetestComponent,
    ListtestComponent,
    FooterComponent,
    HeaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [HttpClient, TestService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
