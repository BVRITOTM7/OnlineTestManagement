import { Component, OnInit } from '@angular/core';
import { Test, TestService } from '../test.service';
import{Router}from '@angular/router';

@Component({
  selector: 'app-addtest',
  templateUrl: './addtest.component.html',
  styleUrls: ['./addtest.component.css']
})
export class AddtestComponent implements OnInit {
  user: Test = new Test(0,"","","","","",0,0,"","");

  constructor(
    private testservice:TestService,private router:Router){}


  ngOnInit(): void {
  }
  addTest():void{
    console.log(this.user);
    this.testservice.addTest(this.user).subscribe(data =>{ alert("Test is added successfully.");});
  }
}

    
 